import random

# ASCII-Art für die Karten
CARD_ART = {
    'A': ['┌───────┐', '│A      │', '│       │', '│      A│', '└───────┘'],
    '2': ['┌───────┐', '│2      │', '│       │', '│      2│', '└───────┘'],
    '3': ['┌───────┐', '│3      │', '│       │', '│      3│', '└───────┘'],
    '4': ['┌───────┐', '│4      │', '│       │', '│      4│', '└───────┘'],
    '5': ['┌───────┐', '│5      │', '│       │', '│      5│', '└───────┘'],
    '6': ['┌───────┐', '│6      │', '│       │', '│      6│', '└───────┘'],
    '7': ['┌───────┐', '│7      │', '│       │', '│      7│', '└───────┘'],
    '8': ['┌───────┐', '│8      │', '│       │', '│      8│', '└───────┘'],
    '9': ['┌───────┐', '│9      │', '│       │', '│      9│', '└───────┘'],
    '10': ['┌───────┐', '│10     │', '│       │', '│     10│', '└───────┘'],
    'J': ['┌───────┐', '│J      │', '│       │', '│      J│', '└───────┘'],
    'Q': ['┌───────┐', '│Q      │', '│       │', '│      Q│', '└───────┘'],
    'K': ['┌───────┐', '│K      │', '│       │', '│      K│', '└───────┘']
}

# Kartendeck erstellen
def create_deck():
    """Erstellt ein Kartendeck aus den Kartenwerten und den vier Farben."""
    values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    suits = ['♠', '♥', '♦', '♣']
    deck = [value + suit for value in values for suit in suits]
    random.shuffle(deck)  # Mischen des Decks
    return deck

# Wert einer Karte bestimmen
def card_value(card):
    """Bestimmt den Wert einer Karte für das Spiel."""
    if card[0] in ['J', 'Q', 'K']:
        return 10
    elif card[0] == 'A':
        return 11  # Der Wert von 'A' kann auch 1 sein, aber wir behandeln es später
    else:
        return int(card[:-1])

# Karten ausgeben
def print_card(card):
    """Gibt eine Karte als ASCII-Art aus."""
    card_art = CARD_ART[card[:-1]]  # Erhalte ASCII-Art der Karte
    for line in card_art:
        print(line)
    print()

# Hand des Spielers ausgeben
def print_hand(hand):
    """Gibt die Hand des Spielers aus, um die Karten darzustellen."""
    print("Deine Hand:")
    for card in hand:
        print_card(card)
    print()

# Punktzahl berechnen
def calculate_hand_value(hand):
    """Berechnet den Wert einer Hand und berücksichtigt Asse als 1 oder 11."""
    value = 0
    aces = 0
    for card in hand:
        value += card_value(card)
        if card[0] == 'A':
            aces += 1
    # Verarbeite Asse, da sie als 11 oder 1 zählen können
    while value > 21 and aces:
        value -= 10
        aces -= 1
    return value

# Spielablauf
def play_blackjack():
    """Spielt eine Runde Blackjack."""
    global total_calories  # Variable für den globalen Kalorienwert (nur zum Beispiel)

    deck = create_deck()  # Neues Deck erstellen

    # Spieler- und Dealerhände
    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]

    # Zeige die Karten des Spielers
    print_hand(player_hand)
    print(f"Dein Punktestand: {calculate_hand_value(player_hand)}")

    # Zeige nur die erste Karte des Dealers
    print("Karten des Dealers:")
    print_card(dealer_hand[0])
    print("")

    # Spielerzug (Hit oder Stand)
    while True:
        action = input("Möchtest du eine Karte ziehen (hit) oder stehen bleiben (stand)? ").lower()
        if action == "hit":
            player_hand.append(deck.pop())
            print_hand(player_hand)
            print(f"Dein Punktestand: {calculate_hand_value(player_hand)}")
            if calculate_hand_value(player_hand) > 21:
                print("Du hast überzogen! Du hast verloren.")
                return
        elif action == "stand":
            break
        else:
            print("Ungültige Eingabe. Bitte gib 'hit' oder 'stand' ein.")

    # Dealerzug
    print("Der Dealer deckt seine zweite Karte auf:")
    print_card(dealer_hand[1])
    while calculate_hand_value(dealer_hand) < 17:
        print("Der Dealer zieht eine Karte.")
        dealer_hand.append(deck.pop())
        print_hand(dealer_hand)
        if calculate_hand_value(dealer_hand) > 21:
            print("Der Dealer hat überzogen! Du hast gewonnen.")
            return

    # Vergleiche die Punktestände
    player_score = calculate_hand_value(player_hand)
    dealer_score = calculate_hand_value(dealer_hand)

    print(f"Dein Punktestand: {player_score}")
    print(f"Punktestand des Dealers: {dealer_score}")

    if player_score > dealer_score:
        print("Du hast gewonnen!")
    elif player_score < dealer_score:
        print("Der Dealer hat gewonnen!")
    else:
        print("Unentschieden!")

# Hauptspiel Schleife
def main():
    while True:
        play_blackjack()  # Eine Runde Blackjack spielen
        again = input("Möchtest du noch eine Runde spielen? (j/n): ").lower()
        if again != 'j':
            print("Danke fürs Spielen!")
            break

if __name__ == "__main__":
    main()
