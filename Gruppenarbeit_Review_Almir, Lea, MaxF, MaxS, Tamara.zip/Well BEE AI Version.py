import tkinter as tk
from tkinter import simpledialog, messagebox
from PIL import Image, ImageTk
import pandas as pd
import smtplib
import time
import threading
from datetime import datetime

# Globale Variablen für das Tracking
total_calories = 0
total_water = 0
total_training_minutes = 0
mood = ""

# DataFrame zur Speicherung der Eingaben
data = pd.DataFrame(columns=["Date", "Mood", "Calories", "Water", "Training Minutes"])

# Funktion zur Abfrage der Gemütslage
def ask_mood():
    global mood
    # Abfrage der Gemütslage
    mood = simpledialog.askstring("Gemütslage", "Wie geht es dir heute? (Sehr gut, Gut, Neutral, Schlecht, Sehr schlecht)")
    
    # Lustigen Kommentar basierend auf der Gemütslage
    if mood.lower() == "sehr gut":
        messagebox.showinfo("Motivation", "Fantastisch! Weiter so, du rockst den Tag!")
    elif mood.lower() == "gut":
        messagebox.showinfo("Motivation", "Gut gemacht! Du bist auf dem richtigen Weg!")
    elif mood.lower() == "neutral":
        messagebox.showinfo("Motivation", "Alles im Griff! Jetzt Gas geben!")
    elif mood.lower() == "schlecht":
        messagebox.showinfo("Motivation", "Kopf hoch! Du kannst alles schaffen!")
    elif mood.lower() == "sehr schlecht":
        messagebox.showinfo("Motivation", "Nicht aufgeben, morgen wird besser!")
    else:
        messagebox.showerror("Fehler", "Bitte gib eine gültige Gemütslage ein!")

# Funktion zum Tracken des Trainings
def track_training():
    global total_training_minutes
    minutes = simpledialog.askinteger("Training", "Wie viele Minuten hast du heute trainiert?")
    if minutes:
        total_training_minutes += minutes
        messagebox.showinfo("Training", f"Du hast {minutes} Minuten trainiert. Gesamt: {total_training_minutes} Minuten.")
    else:
        messagebox.showerror("Fehler", "Bitte gib eine gültige Zeit ein.")

# Funktion zum Setzen eines Trainingsreminders
def set_training_reminder():
    reminder_time = simpledialog.askinteger("Reminder", "In wie vielen Minuten möchtest du erinnert werden?")
    
    if reminder_time:
        def reminder():
            time.sleep(reminder_time * 60)
            messagebox.showinfo("Reminder", f"Zeit für dein Training! Starte jetzt!")
        
        # Starte den Reminder in einem neuen Thread, damit die GUI nicht blockiert wird
        threading.Thread(target=reminder).start()
    else:
        messagebox.showerror("Fehler", "Bitte gib eine gültige Zeit ein.")

# Funktion zum Tracken der Kalorienaufnahme
def track_calories():
    global total_calories
    breakfast = simpledialog.askinteger("Frühstück", "Wie viele Kalorien hast du zum Frühstück gegessen?")
    lunch = simpledialog.askinteger("Mittagessen", "Wie viele Kalorien hast du zum Mittagessen gegessen?")
    dinner = simpledialog.askinteger("Abendessen", "Wie viele Kalorien hast du zum Abendessen gegessen?")
    snacks = simpledialog.askinteger("Snacks", "Wie viele Kalorien hast du durch Snacks gegessen?")
    
    total_calories = (breakfast or 0) + (lunch or 0) + (dinner or 0) + (snacks or 0)
    messagebox.showinfo("Kalorien", f"Gesamt-Kalorienaufnahme: {total_calories} kcal.")

# Funktion zum Tracken der Wasseraufnahme
def track_water():
    global total_water
    glasses = simpledialog.askinteger("Wasseraufnahme", "Wie viele Gläser Wasser hast du heute getrunken? (1 Glas = 250ml)")
    if glasses:
        total_water += glasses * 0.25
        messagebox.showinfo("Wasser", f"Du hast insgesamt {total_water} Liter Wasser getrunken.")
    else:
        messagebox.showerror("Fehler", "Bitte gib eine gültige Anzahl an Gläsern ein.")

# Funktion zum Speichern und Versenden der Daten per E-Mail
def save_and_send():
    global data
    today = datetime.now().strftime("%Y-%m-%d")
    data = data.append({
        "Date": today,
        "Mood": mood,
        "Calories": total_calories,
        "Water": total_water,
        "Training Minutes": total_training_minutes
    }, ignore_index=True)
    
    # Speichern der Daten in einer CSV-Datei
    data.to_csv("well_bee_data.csv", index=False)
    
    # Sende die Daten per E-Mail (Beispiel)
    send_email()

# Funktion zum Versenden der E-Mail
def send_email():
    try:
        # E-Mail-Konfiguration (hier beispielhaft)
        sender = "deine.email@example.com"
        receiver = "empfaenger.email@example.com"
        password = "dein_passwort"
        
        # Erstellen der Nachricht
        subject = "Well Bee - Wöchentliche Daten"
        body = f"Hier sind deine Daten:\n{data.tail(1)}"
        message = f"Subject: {subject}\n\n{body}"
        
        # Verbindung zum SMTP-Server und Senden der E-Mail
        with smtplib.SMTP_SSL("smtp.example.com", 465) as server:
            server.login(sender, password)
            server.sendmail(sender, receiver, message)
        
        messagebox.showinfo("E-Mail", "Deine Daten wurden per E-Mail versendet!")
    except Exception as e:
        messagebox.showerror("Fehler", f"Fehler beim Senden der E-Mail: {str(e)}")

# GUI-Setup
root = tk.Tk()
root.title("Well Bee App")
root.geometry("400x600")

# Frames für die Trennung
mood_frame = tk.Frame(root)
training_frame = tk.Frame(root)
calories_frame = tk.Frame(root)

# Mood Frame
tk.Label(mood_frame, text="Wie geht's dir?", font=("Arial", 16)).pack(pady=10)
tk.Button(mood_frame, text="Gemütslage abfragen", command=ask_mood).pack(pady=10)
mood_frame.pack(pady=20)

# Training Frame
tk.Label(training_frame, text="Training Tracking", font=("Arial", 16)).pack(pady=10)
tk.Button(training_frame, text="Training tracken", command=track_training).pack(pady=10)
tk.Button(training_frame, text="Training Reminder setzen", command=set_training_reminder).pack(pady=10)
training_frame.pack(pady=20)

# Kalorien und Wasser Frame
tk.Label(calories_frame, text="Kalorien und Wasser Tracking", font=("Arial", 16)).pack(pady=10)
tk.Button(calories_frame, text="Kalorien tracken", command=track_calories).pack(pady=10)
tk.Button(calories_frame, text="Wasseraufnahme tracken", command=track_water).pack(pady=10)
calories_frame.pack(pady=20)

# Beenden-Button
tk.Button(root, text="Beenden und Daten senden", command=save_and_send).pack(pady=10)

# Starten der GUI
root.mainloop()
